#!/usr/local/bin/perl -w

# Author: Stephane Gigandet
# Date: 02/05/01

# Quick script to generate a list of FTP Syntest cases.
# Recursively parse directories, sort files, retrieve the description and print list to STDOUT.

sub list_directory($$) {
    my $path = shift;
    my $indent = shift;

    opendir (DH, $path) or die "Unable to open directory $path: $!\n" ;
    my @readdir = readdir(DH);
    close DH;

    # put a leading 0 for files like user1.xml -> user01.xml
    my $j = 0;
    my %original_readdir;
    foreach my $dir (@readdir) {
        my $original = $dir;
        $readdir[$j] = ' ' . $readdir[$j];
        $readdir[$j] =~ s/(\D)(\d\.xml)$/${1}0$2/;
        $readdir[$j] =~ s/^ //;
        $original_readdir{$readdir[$j]} = $original;
        $j++;
    }

    my @sub_dirs = ();
    my $i = 1;

    my $dashes = $path;
    $dashes =~ s/./-/g;
    print "$indent$path\n$indent$dashes\n";

    my $k=-1;
   
    foreach my $filename (sort @readdir) {

        $k++;

        chomp($filename);

        next if (($filename eq '.') or ($filename eq '..') or ($filename eq 'CVS'));
        next if (($filename eq 'init.xml') or ($filename eq 'tests.xml') );

        if ($filename =~ /^(.*)\.xml$/) {
            print "$indent$i) $original_readdir{$filename} - ";
            open (IN, "<" . $path . "/". $original_readdir{$filename});
            my $lines = join ('', <IN>);
            close (IN);
            $lines =~ s/(\n|(\s)+)/ /g;
            my $description = "no description";
            if ($lines =~ /<description>(.*)<\/description>/) {
                $description = $1;
            }
            $description =~ s/^(.{40}).*$/$1\.\.\./;
            print "$description\n";
            $i++;
        }

        if (-d "$path/$filename" and not -l "$path/$filename") {
            push @sub_dirs, $filename;
        }
    }

    $i--;

    print "\n";

    foreach my $sub_dir (@sub_dirs) {
        $i += list_directory("$path/$sub_dir", $indent . "\t");
    }

    print "${indent}Total for $path: $i\n\n";

    return $i; 
}


list_directory('.','');
